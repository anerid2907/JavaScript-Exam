const questions = [
    {
        question: "What is the capital of India?",
        choices: ["Mumbai", "Chennai", "New Delhi","Kolkata"],
        correctAnswer: 3
    },
    {
        question: "Which planet is known as the Red Planet?",
        choices: ["Earth",  "Jupiter","Mars","Saturn"],
        correctAnswer: 3
    },
    {
        question: "What is the largest mammal?",
        choices: ["Elephant", "Blue Whale", "Shark", "Giraffe"],
        correctAnswer: 2
    }
];

let currentQuestion = 0;
let score = 0;

const questionElement = document.getElementById("question");
const mychoices = document.getElementById("choices");
const myscore = document.getElementById("score");
const nextButton = document.getElementById("next-button");

function loadQuestion() {
    const current = questions[currentQuestion];
    questionElement.innerText = current.question;
    mychoices.innerHTML = '';

    current.choices.forEach((choice, index) => {
        const button = document.createElement('button');
        button.innerText = choice;
        button.onclick = () => checkAnswer(index);
        mychoices.appendChild(button);
    });
}

function checkAnswer(selectedIndex) {
    const correctAnswer = questions[currentQuestion].correctAnswer;

    if (selectedIndex === correctAnswer) {
        score++;
        myscore.innerText = score;
    }

    nextButton.disabled = false;
}

nextButton.onclick = () => {
    currentQuestion++;

    if (currentQuestion < questions.length) {
        loadQuestion();
        nextButton.disabled = true;
    } else {
        showLeaderboard();
    }
};

function showLeaderboard() {
    document.getElementById("question-container").classList.add('hidden');
    document.getElementById("score-container").classList.add('hidden');
    document.getElementById("leaderboard-container").classList.remove('hidden');

    const leaderboard = JSON.parse(localStorage.getItem("leaderboard") || "[]");

    leaderboard.push(score);
    leaderboard.sort((a, b) => b - a);
    localStorage.setItem("leaderboard", JSON.stringify(leaderboard));

    const leaderboardList = document.getElementById("leaderboard");
    leaderboardList.innerHTML = '';

    leaderboard.forEach((score, index) => {
        const li = document.createElement('li');
        li.innerText = `Rank ${index + 1}: ${score} points`;
        leaderboardList.appendChild(li);
    });
}

loadQuestion();
nextButton.disabled = true;
